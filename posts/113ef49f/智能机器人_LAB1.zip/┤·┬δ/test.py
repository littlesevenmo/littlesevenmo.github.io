#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import cv2
import serial

# from picamera.array import PiRGBArray
# from picamera import PiCamera
# import time
# import copy
import video
from matplotlib import pyplot as plt

class App(object):
    def __init__(self, color):
        self.cam = video.create_capture(0)
#         self.cam = PiCamera()
#         self.cam.resolution = (320,240)
#         self.cam.framerate = 32
#         self.rCa = PiRGBArray(self.cam, size=(320,240))
#         time.sleep(0.1) 
#        self.cam.capture(self.rCa, format='bgr')
#        self.frame = self.rCa.array
#        ret, self.frame = self.cam.read()
        cv2.namedWindow('camshift')
        if color == 0:
            self.roi = cv2.imread( 'hong.jpg' )
            self.flag = "Hong"
        else :
            self.flag = "Lan"
            #self.roi = cv2.imread('hong.jpg')
            #self.roi = cv2.imread('lan.jpg')
            #self.roi = cv2.imread('lena.jpg')
            self.roi = cv2.imread('fense.jpg')
            self.selection = None
            self.tracking_state = 0
            self.show_backproj = False
#         self.ser = serial.Serial('/dev/ttyAMA0',115200,timeout=0.5)

                    
    def start(self):
        self.tracking_state = 0
        #x, y = np.int16([220, 110]) # BUG
        if self.flag == 'Hong':
                self.selection = (4, 6, 407, 304)
        else:
            self.selection = (40, 54, 296, 230)
            self.tracking_state = 1
    #        print "start"

    def show_hist(self):
        bin_count = self.hist.shape[0]
        bin_w = 24
        img = np.zeros((256, bin_count*bin_w, 3), np.uint8)

        #for i in xrange(bin_count):
        for i in range(bin_count):
            h = int(self.hist[i])
            #画矩形
            cv2.rectangle(img, (i*bin_w+2, 255), ((i+1)*bin_w-2, 255-h), (int(180.0*i/bin_count), 255, 255), -1)
        img = cv2.cvtColor(img, cv2.COLOR_HSV2BGR)
        cv2.imshow('hist', img)

    def run(self):
        roi = self.roi
        self.start()
        while True:
#         for frame in self.cam.capture_continuous(self.rCa, format='bgr', use_video_port=True):
#           读取相机的数据流
            ret, self.frame = self.cam.read()
#             self.frame = frame.array
#           vis作为相机视频的一个备份，做深复制，用于显示输出
            vis = self.frame.copy()
#             vis = copy.deepcopy(self.frame)
#           颜色空间转换，flag决定转换类型，cv2.COLOR_BGR2HSV为BGR转HSV空间
#           HSV 为色相，饱和度，明度
#           RGB颜色空间对光照亮度变化较为敏感，
#           为了减少此变化对跟踪效果的影响，首先将图像从RGB空间转换到HSV空间。
            hsv = cv2.cvtColor(self.frame, cv2.COLOR_BGR2HSV)
            cv2.imshow('hsv', hsv)
#           设置阈值，三通道低于(0,60,32)的置为0，高于(180,255,255)的置为0，在他俩之间的，设为255
#           Why?为什么？
#           阈值改为检测偏红色的东西，根据阈值进行掩膜，
            mask = cv2.inRange(hsv, np.array((0., 0., 213.)), np.array((255., 128., 255.))) #偏红色的
            #mask = cv2.inRange(hsv, np.array((0., 60., 32.)), np.array((180., 255., 255.)))
#             self.selection = 1
#           现在，mask是一个只有黑白的图像流
            cv2.imshow('mask', mask)
            if self.selection:
#                 x0, y0, x1, y1 = 220, 110, 358, 245
                x0, y0, x1, y1 = self.selection
                self.track_window = (x0, y0, x1-x0, y1-y0)      #（40,54，256,176）初始化框的范围
#                 hsv_roi = hsv[y0:y1, x0:x1]
#                 mask_roi = mask[y0:y1, x0:x1]
#               roi是读入的图片，
                hsv_roi = cv2. cvtColor(roi,cv2. COLOR_BGR2HSV)
                #读入的图片也要进行掩模处理
                mask_roi = cv2.inRange(hsv_roi, np.array((0., 0., 213.)), np.array((255., 128., 255.)))
#                mask_roi = cv2.inRange(hsv_roi, np.array((0., 60., 32.)), np.array((180., 255., 255.)))
                #瞅你咋地
                cv2.namedWindow("mask_roi")
                cv2.imshow('mask_roi', mask_roi)
                #一维直方图
                #cv2.calcHist是直方图计算函数
                ##################直方图#################
                ################函数原型#################
                #cv2.calcHist(images, channels, mask, histSize, ranges[, hist[, accumulate ]]) #返回hist
                #举例说明：
                #image = cv2.imread("D:/histTest.jpg", 0)
                #hist = cv2.calcHist([image],
                #[0], #使用的通道
                #None, #没有使用mask
                #[256], #HistSize
                #[0.0,255.0]) #直方图柱的范围

                hist = cv2.calcHist( [hsv_roi], [0], mask_roi, [16], [0, 180] )
                #hist.shape=(16,1)
                #H-S联合二维直方图
                #hist2 = cv2.calcHist( [hsv_roi], [0,1],None, [16,24], [0, 180,0 , 255] )
                #hist2 = cv2.calcHist( [hsv_roi], [0,2],None, [18,24], [0, 180,0 , 255] )
                #归一化，让最大值是255
                cv2.normalize(hist, hist, 0, 255, cv2.NORM_MINMAX);
                #转换为一维吗？因为reshape(-1)是根据其他的维度来算这个这个维度
                self.hist = hist.reshape(-1)
                #二维直方图显示
                #plt.imshow(hist2,interpolation = 'nearest')
                #plt.show()
                #self.show_hist()
                #在我的电脑上，vis是（288,352,3）
                #选择感兴趣的区间为（54~230,40~296）
                vis_roi = vis[y0:y1, x0:x1]
                #图像非运算
                #函数原型bitwise_and(src1, src2, dst=None, mask=None)
                cv2.bitwise_not(vis_roi, vis_roi)
                #vis_roi是对视频流取相反得到的结果
                cv2.namedWindow("vis_roi_bit_not")
                #好像后面并没有用到组合格vis_roi
                cv2.imshow('vis_roi_bit_not', vis_roi)
                vis[mask == 0] = 0

            if self.tracking_state == 1:
                #把selection = None 这样就不再进行第一步了
                self.selection = None
                #cv2.calcBackProject直方图反向投影。
                #反向投影可以用来做图像分割，寻找感兴趣区间。它会输出与输入图像大小相同的图像，
                #每一个像素值代表了输入图像上对应点属于目标对象的概率，概率越高，越亮。
                #简言之，输出图像中像素值越高的点越可能代表想要查找的目标。
                #直方图投影经常与camshift（追踪算法）算法一起使用。 

                #然后对其中的H分量(色调)作直方图，
                #在直方图中代表了不同H分量值出现的概率或者像素个数，
                #就是说可以查找出H分量大小为h的概率或者像素个数，即得到了颜色概率查找表。

                #将图像中每个像素的值用其颜色出现的概率对替换，就得到了颜色概率分布图。
                #这个过程就叫反向投影，颜色概率分布图是一个灰度图像。

                #得到的是一个概率图
                prob = cv2.calcBackProject([hsv], [0], self.hist, [0, 180], 1)
                cv2.namedWindow("prob1")
                #显示概率图1
                cv2.imshow('prob1', prob)

                #与掩膜相与
                prob &= mask
                cv2.namedWindow("prob2")
                #显示概率图2
                cv2.imshow('prob2', prob)
                #criteria：迭代停止的模式选择，这是一个含有三个元素的元组型数。格式为（type,max_iter,epsilon） 
                #其中，type又有两种选择： 
                #—–cv2.TERM_CRITERIA_EPS :移动至少一个像素点 
                #—- cv2.TERM_CRITERIA_COUNT：迭代次数超过10（这里是）停止。 
                #—-cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_MAX_ITER，两者合体，任意一个满足结束。

                term_crit = ( cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 1 )

                #CamShift算法的全称是"Continuously Adaptive Mean-SHIFT"，即：连续自适应的MeanShift算法。
                #其基本思想是对视频序列的所有图像帧都作MeanShift运算，
                #并将上一帧的结果（即搜索窗口的中心位置和窗口大小）作为下一帧MeanShift算法的搜索窗口的初始值，
                #如此迭代下去。

                #算法过程为：
                #(1).初始化搜索窗
                #(2).计算搜索窗的颜色概率分布（反向投影）
                #(3).运行meanshift算法，获得搜索窗新的大小和位置。
                #(4).在下一帧视频图像中用(3)中的值重新初始化搜索窗的大小和位置，再跳转到(2)继续进行。
                track_box, self.track_window = cv2.CamShift(prob, self.track_window, term_crit)

                #大小计算：
                #零阶矩是搜索窗口内所有像素的积分，即所有像素值之和，物理上的意义是计算搜索窗口的尺寸。
                #经过目标的H分量直方图反向投影后，目标区域的搜索窗口大部分像素值归一化后应该是最大值255，
                #如果计算出来零阶矩大于某一阈值，可以认为此时目标铺满了整个搜索窗口，
                #有理由认为在搜索窗口之外的区域还存在目标区域，需要增大搜索窗口的尺寸；
                #相应的，如果零阶矩小于某一阈值，则需要缩小搜索窗口的尺寸，
                #如此一来，当目标的大小发生变化的时候，CamShift算法就可以自适应的调整目标区域进行跟踪。
#                 if track_box[0][1] <= 240:
#             self.ser.write(str(int(track_box[0][0])-320) + " " + str(int(track_box[0][1])-240))
#             print str(int(track_box[0][0])-320) + " " + str(int(track_box[0][1])-240)
                if track_box[1][1] <= 1:
                    self.tracking_state = 0
                    self.start()
                else:
                    if self.show_backproj:
                        vis[:] = prob[...,np.newaxis]
                    try: 
                        #画椭圆
                        #五个参数：椭圆中心，半长轴的长度，椭圆旋转的角度，椭圆的起始角度，椭圆的结束角度
                        cv2.ellipse(vis, track_box, (0, 0, 255), 2)
#                       输出椭圆的参数
                        a = str(track_box[0][0])+" "+str(track_box[0][1])+" "+str(round(track_box[1][0],2))\
                                       +" "+str(round(track_box[1][1],2))+" "+str(round(track_box[2],2))+"\r\n"
                        print( a)
#                         self.ser.write(a)
                    except: print( track_box)

            cv2.imshow('camshift', vis)

            ch = 0xFF & cv2.waitKey(5)
            if ch == 27:
                break
            if ch == ord('b'):
                self.show_backproj = not self.show_backproj
            if ch == ord('r'):
                self.tracking_state = 0
                self.start()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    import sys
    try: color = sys.argv[1]
    except: color = 1
    #print( __doc__)
    a = App(color)
    a.run()

    
# TODO