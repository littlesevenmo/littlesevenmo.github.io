#include "hello.h"
#include <stdio.h>

void sayHello()
{
    printf("Hello\n");
}
